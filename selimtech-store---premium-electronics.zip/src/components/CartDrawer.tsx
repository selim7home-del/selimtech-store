import React, { useState } from 'react';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  MessageCircle, 
  ArrowRight, 
  Truck, 
  ShieldCheck,
  MapPin,
  User,
  Phone
} from 'lucide-react';
import { CartItem, StoreConfig } from '../types/store';
import { generateCartWhatsAppLink } from '../utils/whatsapp';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  config: StoreConfig;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  onExploreProducts: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  config,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onExploreProducts,
}) => {
  if (!isOpen) return null;

  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [customerNotes, setCustomerNotes] = useState('');
  const [showAddressForm, setShowAddressForm] = useState(false);

  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const isFreeShipping = subtotal >= config.freeShippingThreshold;
  const shippingAmount = isFreeShipping || items.length === 0 ? 0 : 500;
  const grandTotal = subtotal + shippingAmount;

  const freeShippingDifference = Math.max(0, config.freeShippingThreshold - subtotal);
  const freeShippingProgress = Math.min(100, (subtotal / config.freeShippingThreshold) * 100);

  const handleWhatsAppCheckout = () => {
    if (items.length === 0) return;
    const url = generateCartWhatsAppLink(items, config, {
      name: customerName.trim() || undefined,
      phone: customerPhone.trim() || undefined,
      address: deliveryAddress.trim() || undefined,
      notes: customerNotes.trim() || undefined,
    });
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/60 backdrop-blur-xs flex justify-end">
      <div 
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between animate-in slide-in-from-right duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-blue-600" />
            <h3 className="font-bold text-base text-slate-900">Your Shopping Bag</h3>
            <span className="text-xs bg-blue-100 text-blue-700 font-semibold px-2 py-0.5 rounded-full">
              {items.reduce((s, i) => s + i.quantity, 0)} items
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Shipping Progress Indicator */}
        <div className="bg-blue-50/70 px-5 py-2.5 border-b border-blue-100 text-xs">
          <div className="flex items-center justify-between text-blue-950 mb-1">
            <span className="flex items-center gap-1.5 font-medium">
              <Truck className="w-3.5 h-3.5 text-blue-600" />
              {isFreeShipping ? (
                <span className="font-bold text-emerald-700">You unlocked Free Express Shipping!</span>
              ) : (
                <span>Add <strong>{config.currencySymbol}{freeShippingDifference.toFixed(0)}</strong> more for <strong>FREE Shipping</strong></span>
              )}
            </span>
          </div>
          <div className="w-full bg-blue-200/60 h-1.5 rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all duration-300 rounded-full ${isFreeShipping ? 'bg-emerald-600' : 'bg-blue-600'}`}
              style={{ width: `${freeShippingProgress}%` }}
            />
          </div>
        </div>

        {/* Drawer Items List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3">
              <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
                <ShoppingBag className="w-8 h-8" />
              </div>
              <h4 className="font-bold text-base text-slate-800">Your cart is empty</h4>
              <p className="text-xs text-slate-500 max-w-xs">
                Explore our catalog to find premium smartphones, laptops, audio gear and accessories.
              </p>
              <button
                onClick={() => {
                  onClose();
                  onExploreProducts();
                }}
                className="mt-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl transition-colors"
              >
                Browse Catalog
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-500 pb-1">
                <span>Selected Electronics</span>
                <button
                  onClick={onClearCart}
                  className="text-rose-600 hover:text-rose-700 text-xs font-medium"
                >
                  Clear Bag
                </button>
              </div>

              {items.map((item) => (
                <div
                  key={item.product.id}
                  className="flex gap-3 p-3 bg-slate-50/70 border border-slate-200 rounded-xl items-center"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-16 h-16 rounded-lg object-cover bg-white border border-slate-200 shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-1 min-w-0">
                    <h5 className="font-bold text-xs text-slate-900 truncate">
                      {item.product.name}
                    </h5>
                    <p className="text-[11px] text-slate-500">{item.product.brand}</p>
                    <p className="text-xs font-bold text-blue-600 mt-1 tabular-nums">
                      {config.currencySymbol}{item.product.price.toLocaleString()}
                    </p>
                  </div>

                  <div className="flex flex-col items-end gap-2 shrink-0">
                    {/* Quantity controls */}
                    <div className="flex items-center border border-slate-300 rounded-lg bg-white overflow-hidden text-xs">
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                        className="px-2 py-1 text-slate-600 hover:bg-slate-100"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="px-2 font-mono font-bold text-slate-800">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                        className="px-2 py-1 text-slate-600 hover:bg-slate-100"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <button
                      onClick={() => onRemoveItem(item.product.id)}
                      className="text-slate-400 hover:text-rose-600 transition-colors p-1"
                      title="Remove Item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}

              {/* Optional Customer Delivery Details */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddressForm(!showAddressForm)}
                  className="w-full flex items-center justify-between text-xs font-semibold text-slate-700 hover:text-blue-600 p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  <span className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-blue-600" />
                    {showAddressForm ? 'Hide Delivery Details' : 'Add Delivery Info to WhatsApp (Optional)'}
                  </span>
                  <span>{showAddressForm ? '▲' : '▼'}</span>
                </button>

                {showAddressForm && (
                  <div className="p-3 bg-white border border-slate-200 border-t-0 rounded-b-xl space-y-2 text-xs">
                    <div>
                      <label className="block text-[11px] text-slate-600 font-medium mb-0.5">Your Name</label>
                      <input
                        type="text"
                        placeholder="John Doe"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-600 font-medium mb-0.5">Contact Phone</label>
                      <input
                        type="tel"
                        placeholder="+1 555-0199"
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-600 font-medium mb-0.5">Delivery Address / City</label>
                      <input
                        type="text"
                        placeholder="45 Tech Avenue, Apt 2, City"
                        value={deliveryAddress}
                        onChange={(e) => setDeliveryAddress(e.target.value)}
                        className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs"
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Drawer Footer with Subtotal & WhatsApp Checkout CTA */}
        {items.length > 0 && (
          <div className="p-5 border-t border-slate-200 bg-slate-50/90 space-y-3">
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal ({items.length} items)</span>
                <span className="font-semibold tabular-nums">{config.currencySymbol}{subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Estimated Shipping</span>
                <span className="font-semibold">
                  {isFreeShipping ? (
                    <span className="text-emerald-600 font-bold">FREE</span>
                  ) : (
                    <span className="tabular-nums">{config.currencySymbol}{shippingAmount}</span>
                  )}
                </span>
              </div>
              <div className="flex justify-between text-base font-extrabold text-slate-950 pt-2 border-t border-slate-200">
                <span>Estimated Total</span>
                <span className="text-blue-600 tabular-nums">
                  {config.currencySymbol}{grandTotal.toLocaleString()}
                </span>
              </div>
            </div>

            {/* WhatsApp Checkout Button */}
            <button
              onClick={handleWhatsAppCheckout}
              className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-sm rounded-xl transition-all shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4 fill-white/20" />
              <span>Checkout Order via WhatsApp</span>
            </button>

            <p className="text-[11px] text-slate-400 text-center">
              Sends an itemized order summary to official WhatsApp number <strong className="text-slate-600">{config.displayWhatsApp || config.whatsappNumber}</strong>.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
