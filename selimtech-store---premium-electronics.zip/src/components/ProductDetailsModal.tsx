import React, { useState } from 'react';
import { 
  X, 
  MessageCircle, 
  ShoppingBag, 
  Star, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Check, 
  Plus, 
  Minus,
  Sparkles,
  MapPin,
  User,
  FileText
} from 'lucide-react';
import { Product, StoreConfig } from '../types/store';
import { generateSingleProductWhatsAppLink } from '../utils/whatsapp';

interface ProductDetailsModalProps {
  product: Product | null;
  config: StoreConfig;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
}

export const ProductDetailsModal: React.FC<ProductDetailsModalProps> = ({
  product,
  config,
  onClose,
  onAddToCart,
}) => {
  if (!product) return null;

  const [quantity, setQuantity] = useState(1);
  const [customerName, setCustomerName] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [specialNote, setSpecialNote] = useState('');
  const [showOrderForm, setShowOrderForm] = useState(false);
  const [isAddedToCart, setIsAddedToCart] = useState(false);

  const totalPrice = (product.price * quantity).toFixed(2);

  const handleIncrement = () => setQuantity((q) => q + 1);
  const handleDecrement = () => setQuantity((q) => (q > 1 ? q - 1 : 1));

  const handleAddToCart = () => {
    onAddToCart(product, quantity);
    setIsAddedToCart(true);
    setTimeout(() => setIsAddedToCart(false), 2000);
  };

  const handleSendWhatsAppOrder = () => {
    const url = generateSingleProductWhatsAppLink(product, quantity, config, {
      name: customerName.trim() || undefined,
      address: customerAddress.trim() || undefined,
      notes: specialNote.trim() || undefined,
    });
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 md:p-6">
      <div 
        className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Sticky Header with Title and Close Button */}
        <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50/80 backdrop-blur-xs">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">{product.brand}</span>
            <span className="text-slate-300">/</span>
            <span className="text-xs text-slate-500 font-medium">{product.categoryLabel}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/80 transition-colors"
            aria-label="Close Product Details"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body with Two-Column Split */}
        <div className="overflow-y-auto p-5 sm:p-7 flex-1">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left: Product Image & Badges */}
            <div className="lg:col-span-5 space-y-4">
              <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-slate-100 border border-slate-200">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                {product.discountPercentage && (
                  <span className="absolute top-3 left-3 bg-rose-600 text-white text-xs font-bold px-2.5 py-1 rounded-md shadow-sm">
                    {product.discountPercentage}% OFF
                  </span>
                )}
              </div>

              {/* Guarantees Box */}
              <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-200/70 space-y-2 text-xs text-slate-600">
                <div className="flex items-center gap-2 text-slate-900 font-semibold">
                  <ShieldCheck className="w-4 h-4 text-blue-600" />
                  <span>{product.warranty}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Truck className="w-4 h-4 text-emerald-600" />
                  <span>Fast Express Dispatch · Free over {config.currencySymbol}{config.freeShippingThreshold.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-2">
                  <RotateCcw className="w-4 h-4 text-purple-600" />
                  <span>7-Day Return / Replacement Guarantee</span>
                </div>
              </div>
            </div>

            {/* Right: Product Details, Specs & Order Controls */}
            <div className="lg:col-span-7 space-y-5">
              <div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 leading-snug">
                  {product.name}
                </h2>

                <div className="flex items-center gap-3 mt-2">
                  <div className="flex items-center text-amber-500 text-xs font-bold gap-1">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <span>{product.rating}</span>
                    <span className="text-slate-400 font-normal">({product.reviewsCount} customer reviews)</span>
                  </div>
                  <span className="text-slate-300">·</span>
                  <span className="text-xs font-semibold text-emerald-600">
                    {product.inStock ? 'Available In Stock' : 'Limited Stock'}
                  </span>
                </div>
              </div>

              {/* Price Row */}
              <div className="flex items-baseline gap-3 py-2 border-y border-slate-100">
                <span className="text-2xl sm:text-3xl font-extrabold text-slate-950 tabular-nums">
                  {config.currencySymbol}{product.price.toLocaleString()}
                </span>
                {product.originalPrice && (
                  <span className="text-base text-slate-400 line-through tabular-nums">
                    {config.currencySymbol}{product.originalPrice.toLocaleString()}
                  </span>
                )}
                {product.discountPercentage && (
                  <span className="text-xs font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded">
                    Save {config.currencySymbol}{(product.originalPrice! - product.price).toLocaleString()}
                  </span>
                )}
              </div>

              {/* Description */}
              <p className="text-sm text-slate-600 leading-relaxed">
                {product.description}
              </p>

              {/* Key Features Bulleted */}
              {product.keyFeatures && product.keyFeatures.length > 0 && (
                <div className="space-y-1.5 pt-1">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Key Highlights
                  </h4>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs text-slate-600">
                    {product.keyFeatures.map((feat, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <Check className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Specifications Table */}
              <div className="space-y-2 pt-2">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Technical Specifications
                </h4>
                <div className="bg-slate-50 rounded-xl border border-slate-200 overflow-hidden divide-y divide-slate-200 text-xs">
                  {Object.entries(product.specifications).map(([key, val]) => (
                    <div key={key} className="grid grid-cols-3 px-3 py-2">
                      <span className="font-semibold text-slate-700">{key}</span>
                      <span className="col-span-2 text-slate-600">{val}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quantity Selector & Instant Total */}
              <div className="pt-2 flex items-center justify-between bg-slate-50/80 p-3 rounded-xl border border-slate-200">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold text-slate-700">Quantity:</span>
                  <div className="flex items-center border border-slate-300 rounded-lg bg-white overflow-hidden">
                    <button
                      onClick={handleDecrement}
                      disabled={quantity <= 1}
                      className="p-1.5 hover:bg-slate-100 disabled:opacity-40 text-slate-600"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="px-3 py-1 text-xs font-bold text-slate-800 font-mono tabular-nums">
                      {quantity}
                    </span>
                    <button
                      onClick={handleIncrement}
                      className="p-1.5 hover:bg-slate-100 text-slate-600"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs text-slate-500">Order Total: </span>
                  <span className="text-base font-extrabold text-blue-600 tabular-nums">
                    {config.currencySymbol}{Number(totalPrice).toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Optional Custom Delivery Info Toggle */}
              <div className="border border-slate-200 rounded-xl p-3 bg-white space-y-2">
                <button
                  type="button"
                  onClick={() => setShowOrderForm(!showOrderForm)}
                  className="w-full flex items-center justify-between text-xs font-semibold text-slate-700 hover:text-blue-600"
                >
                  <span className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-blue-600" />
                    {showOrderForm ? 'Hide Delivery Details' : 'Add Delivery Info to WhatsApp Message (Optional)'}
                  </span>
                  <span className="text-blue-600 text-xs">{showOrderForm ? '▲' : '▼'}</span>
                </button>

                {showOrderForm && (
                  <div className="pt-2 space-y-2 text-xs border-t border-slate-100 mt-2">
                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-0.5">Your Full Name</label>
                      <input
                        type="text"
                        placeholder="e.g. John Doe"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-0.5">Delivery Address / City</label>
                      <input
                        type="text"
                        placeholder="e.g. 123 Main St, Apt 4B, City"
                        value={customerAddress}
                        onChange={(e) => setCustomerAddress(e.target.value)}
                        className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-0.5">Note / Preferred Time</label>
                      <input
                        type="text"
                        placeholder="e.g. Please deliver after 2 PM"
                        value={specialNote}
                        onChange={(e) => setSpecialNote(e.target.value)}
                        className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Primary Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <button
                  onClick={handleSendWhatsAppOrder}
                  className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-sm rounded-xl transition-all shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4 fill-white/20" />
                  <span>Order via WhatsApp Now</span>
                </button>

                <button
                  onClick={handleAddToCart}
                  className={`w-full py-3 px-4 text-sm font-bold rounded-xl transition-all flex items-center justify-center gap-2 ${
                    isAddedToCart
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-900 hover:bg-slate-800 text-white'
                  }`}
                >
                  {isAddedToCart ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Added to Bag!</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4" />
                      <span>Add to Bag</span>
                    </>
                  )}
                </button>
              </div>

              {/* Target WhatsApp Info */}
              <p className="text-[11px] text-slate-400 text-center">
                Orders are sent directly to official SelimTech WhatsApp (<span className="font-mono text-slate-600 font-semibold">{config.displayWhatsApp || config.whatsappNumber}</span>). You can inspect and edit the message before sending.
              </p>

            </div>

          </div>
        </div>
      </div>
    </div>
  );
};
