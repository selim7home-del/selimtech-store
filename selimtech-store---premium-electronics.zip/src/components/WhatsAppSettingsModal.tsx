import React, { useState } from 'react';
import { X, Check, Phone, Settings, AlertCircle, HelpCircle, Save } from 'lucide-react';
import { StoreConfig } from '../types/store';

interface WhatsAppSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: StoreConfig;
  onSaveConfig: (updated: Partial<StoreConfig>) => void;
}

export const WhatsAppSettingsModal: React.FC<WhatsAppSettingsModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig,
}) => {
  if (!isOpen) return null;

  const [whatsappNumber, setWhatsappNumber] = useState(config.whatsappNumber);
  const [displayWhatsApp, setDisplayWhatsApp] = useState(config.displayWhatsApp);
  const [storeName, setStoreName] = useState(config.storeName);
  const [currencySymbol, setCurrencySymbol] = useState(config.currencySymbol);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanNumber = whatsappNumber.replace(/[^0-9]/g, '');
    onSaveConfig({
      whatsappNumber: cleanNumber,
      displayWhatsApp: displayWhatsApp.trim() || `+${cleanNumber}`,
      storeName: storeName.trim(),
      currencySymbol: currencySymbol.trim() || 'ETB ',
    });
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
      onClose();
    }, 1200);
  };

  const handleResetDefault = () => {
    setWhatsappNumber('251911234567');
    setDisplayWhatsApp('+251 91 123 4567');
    setStoreName('SelimTech Store');
    setCurrencySymbol('ETB ');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center">
              <Phone className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900">WhatsApp & Store Setup</h3>
              <p className="text-xs text-slate-500">Configure recipient number for incoming customer orders</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSave} className="p-6 space-y-4">
          {/* Helpful Callout */}
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900 space-y-1">
            <div className="flex items-center gap-1.5 font-bold">
              <HelpCircle className="w-4 h-4 text-blue-600 shrink-0" />
              <span>How this works:</span>
            </div>
            <p>
              When a buyer clicks <strong>Order via WhatsApp</strong>, WhatsApp opens with your chosen number. You can test your personal number right here, or permanently edit <code className="bg-blue-100 px-1 py-0.5 rounded font-mono text-blue-800">src/config/storeConfig.ts</code>.
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1">
              WhatsApp Recipient Number (Digits Only with Country Code)
            </label>
            <input
              type="text"
              value={whatsappNumber}
              onChange={(e) => setWhatsappNumber(e.target.value)}
              placeholder="e.g. 15551234567 or 251911234567"
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm font-mono focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
              required
            />
            <p className="text-[11px] text-slate-500 mt-1">
              Examples: US/Canada: <code className="font-mono text-slate-700">12125550199</code> · UK: <code className="font-mono text-slate-700">447911123456</code> · Nigeria: <code className="font-mono text-slate-700">2348012345678</code>
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1">
              Formatted Display Number (Shown in Header & Footer)
            </label>
            <input
              type="text"
              value={displayWhatsApp}
              onChange={(e) => setDisplayWhatsApp(e.target.value)}
              placeholder="+1 (555) 123-4567"
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Store Name
              </label>
              <input
                type="text"
                value={storeName}
                onChange={(e) => setStoreName(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:border-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Currency Symbol
              </label>
              <input
                type="text"
                value={currencySymbol}
                onChange={(e) => setCurrencySymbol(e.target.value)}
                placeholder="$ or € or £"
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:border-blue-500 outline-none"
              />
            </div>
          </div>

          <div className="pt-2 flex items-center justify-between border-t border-slate-100">
            <button
              type="button"
              onClick={handleResetDefault}
              className="text-xs text-slate-500 hover:text-slate-800 underline"
            >
              Reset to Placeholder
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-slate-200 text-xs font-semibold text-slate-700 rounded-xl hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors shadow-sm"
              >
                {isSaved ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Saved!</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>Save Number</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
