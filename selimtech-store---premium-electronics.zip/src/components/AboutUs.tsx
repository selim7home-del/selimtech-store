import React from 'react';
import { 
  ShieldCheck, 
  Award, 
  Truck, 
  MessageCircle, 
  CheckCircle2, 
  Cpu, 
  Users, 
  Clock,
  Sparkles
} from 'lucide-react';
import { StoreConfig } from '../types/store';

interface AboutUsProps {
  config: StoreConfig;
  onExploreCatalog: () => void;
}

export const AboutUs: React.FC<AboutUsProps> = ({ config, onExploreCatalog }) => {
  const whatsappUrl = `https://wa.me/${config.whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
    `Hello ${config.storeName}! I would like to learn more about your store warranty and bulk purchase options.`
  )}`;

  return (
    <div className="bg-white py-12 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-16">
        
        {/* Hero Banner / Story Intro */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-7 space-y-5">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 border border-blue-200 rounded-full text-blue-700 text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>About SelimTech Store</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-950 tracking-tight leading-tight">
              Empowering Tech Enthusiasts with Original, Verified Hardware
            </h2>

            <p className="text-base text-slate-600 leading-relaxed">
              Founded on the principle of zero-compromise authenticity, <strong>SelimTech Store</strong> has grown into a leading destination for premium smartphones, pro computing hardware, 4K displays, and audio accessories.
            </p>

            <p className="text-sm text-slate-600 leading-relaxed">
              In an electronics landscape flooded with gray-market imports and refurbished clones, we guarantee 100% genuine, brand-new devices directly backed by manufacturer warranties. Our streamlined WhatsApp ordering process eliminates cumbersome account setups and provides you with direct, human customer service.
            </p>

            <div className="pt-2 flex flex-wrap gap-4">
              <button
                onClick={onExploreCatalog}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors shadow-sm"
              >
                Browse Our Catalog
              </button>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5"
              >
                <MessageCircle className="w-4 h-4 fill-white/20" />
                <span>Contact Our Tech Team</span>
              </a>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="bg-slate-900 text-white p-8 rounded-3xl shadow-xl border border-slate-800 space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center font-bold text-lg">
                  S
                </div>
                <div>
                  <h3 className="font-bold text-lg text-white">The SelimTech Promise</h3>
                  <p className="text-xs text-slate-400">Authenticity Guarantee</p>
                </div>
              </div>

              <div className="space-y-4 pt-2">
                <div className="flex items-start gap-3">
                  <ShieldCheck className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-semibold text-white">Factory Sealed Devices</h4>
                    <p className="text-xs text-slate-400 mt-0.5">Every unit is sealed with intact serial numbers verified with brand manufacturers.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Award className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-semibold text-white">Direct Distributor Pricing</h4>
                    <p className="text-xs text-slate-400 mt-0.5">We bypass expensive retail middlemen to pass wholesale-tier savings to you.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-semibold text-white">24/7 WhatsApp Assistance</h4>
                    <p className="text-xs text-slate-400 mt-0.5">Real engineers answer your technical questions before and after your purchase.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 4 Quantitative Proof Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 py-8 border-y border-slate-200">
          <div className="text-center md:text-left space-y-1">
            <span className="text-3xl lg:text-4xl font-extrabold text-blue-600 font-mono tabular-nums">
              10,000+
            </span>
            <p className="text-xs font-bold text-slate-900">Electronics Delivered</p>
            <p className="text-[11px] text-slate-500">Across nationwide customers</p>
          </div>

          <div className="text-center md:text-left space-y-1">
            <span className="text-3xl lg:text-4xl font-extrabold text-emerald-600 font-mono tabular-nums">
              100%
            </span>
            <p className="text-xs font-bold text-slate-900">Authentic Guarantee</p>
            <p className="text-[11px] text-slate-500">Authorized supplier contracts</p>
          </div>

          <div className="text-center md:text-left space-y-1">
            <span className="text-3xl lg:text-4xl font-extrabold text-slate-900 font-mono tabular-nums">
              1-2 Years
            </span>
            <p className="text-xs font-bold text-slate-900">Official Warranty</p>
            <p className="text-[11px] text-slate-500">Included on all major products</p>
          </div>

          <div className="text-center md:text-left space-y-1">
            <span className="text-3xl lg:text-4xl font-extrabold text-blue-600 font-mono tabular-nums">
              &lt; 15 min
            </span>
            <p className="text-xs font-bold text-slate-900">WhatsApp Response</p>
            <p className="text-[11px] text-slate-500">During business hours</p>
          </div>
        </div>

        {/* How We Verify Each Product */}
        <div className="space-y-6">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h3 className="text-2xl font-bold text-slate-900 tracking-tight">
              Our 3-Step Quality Assurance Process
            </h3>
            <p className="text-xs sm:text-sm text-slate-500">
              Before any device is dispatched to your doorstep, our technicians ensure peak condition.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <span className="text-xs font-mono font-bold text-blue-600">STEP 01</span>
              <h4 className="font-bold text-base text-slate-900">Serial & IMEI Verification</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                We confirm each smartphone and computer with manufacturer registries to verify valid warranty coverage and network unblocking.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <span className="text-xs font-mono font-bold text-blue-600">STEP 02</span>
              <h4 className="font-bold text-base text-slate-900">Shockproof Packaging</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Electronics are secured in air-cushioned shock-absorbent cartons designed to withstand transit vibrations and weather.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <span className="text-xs font-mono font-bold text-blue-600">STEP 03</span>
              <h4 className="font-bold text-base text-slate-900">Instant WhatsApp Dispatch Tracking</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                You receive instant dispatch receipts and delivery driver tracking details sent directly to your WhatsApp conversation.
              </p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
