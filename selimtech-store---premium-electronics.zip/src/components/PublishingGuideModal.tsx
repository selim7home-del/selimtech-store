import React, { useState } from 'react';
import { 
  X, 
  Globe, 
  Terminal, 
  UploadCloud, 
  Code2, 
  FileEdit, 
  Check, 
  Copy, 
  ExternalLink,
  ShieldCheck,
  Download
} from 'lucide-react';
import { StoreConfig } from '../types/store';
import { PRODUCTS } from '../data/products';

interface PublishingGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: StoreConfig;
}

export const PublishingGuideModal: React.FC<PublishingGuideModalProps> = ({
  isOpen,
  onClose,
  config,
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'vercel' | 'netlify' | 'github' | 'products' | 'whatsapp'>('vercel');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(id);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleExportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(PRODUCTS, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "selimtech_products.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div 
        className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6 max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900">
                How to Publish Your Store Online for Free
              </h3>
              <p className="text-xs text-slate-500">
                100% Free Hosting, Zero Paid APIs, Easy Product Updates
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-200 bg-slate-100/70 px-6 gap-2 overflow-x-auto text-xs font-semibold">
          <button
            onClick={() => setActiveTab('vercel')}
            className={`py-3 px-3 border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'vercel'
                ? 'border-blue-600 text-blue-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            1. Deploy on Vercel (Fastest)
          </button>
          <button
            onClick={() => setActiveTab('netlify')}
            className={`py-3 px-3 border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'netlify'
                ? 'border-blue-600 text-blue-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            2. Deploy on Netlify
          </button>
          <button
            onClick={() => setActiveTab('products')}
            className={`py-3 px-3 border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'products'
                ? 'border-blue-600 text-blue-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            3. Update Products & Prices
          </button>
          <button
            onClick={() => setActiveTab('whatsapp')}
            className={`py-3 px-3 border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'whatsapp'
                ? 'border-blue-600 text-blue-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            4. Change WhatsApp Number
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-sm text-slate-700 flex-1">
          {activeTab === 'vercel' && (
            <div className="space-y-4">
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-2.5 text-xs text-emerald-900">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  <strong>Vercel is 100% free</strong> for personal and commercial websites. It includes free global CDN, free SSL (https://), and a free custom subdomain like <code>selimtech.vercel.app</code>.
                </span>
              </div>

              <h4 className="font-bold text-slate-900 text-sm">Option A: Via GitHub (Automatic Continuous Deployment)</h4>
              <ol className="list-decimal pl-5 space-y-2 text-xs text-slate-600">
                <li>Create a free account on <a href="https://github.com" target="_blank" rel="noreferrer" className="text-blue-600 underline">GitHub.com</a> and create a new repository (e.g. <code>selimtech-store</code>).</li>
                <li>Push your website code to the repository.</li>
                <li>Go to <a href="https://vercel.com" target="_blank" rel="noreferrer" className="text-blue-600 underline font-semibold">Vercel.com</a> and sign in with GitHub.</li>
                <li>Click <strong>"Add New Project"</strong> and choose your repository.</li>
                <li>Click <strong>"Deploy"</strong>. Within 60 seconds, your website is live worldwide with free HTTPS!</li>
              </ol>

              <h4 className="font-bold text-slate-900 text-sm pt-2">Option B: In 2 Commands via Vercel CLI</h4>
              <div className="relative bg-slate-900 text-slate-100 rounded-xl p-4 font-mono text-xs overflow-x-auto">
                <button
                  onClick={() => copyToClipboard('npm i -g vercel\nvercel', 'cli')}
                  className="absolute top-3 right-3 text-slate-400 hover:text-white p-1 rounded bg-slate-800"
                  title="Copy command"
                >
                  {copiedText === 'cli' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <p className="text-slate-400"># 1. Install free Vercel tool</p>
                <p>npm i -g vercel</p>
                <p className="text-slate-400 mt-2"># 2. Deploy instantly</p>
                <p>vercel</p>
              </div>
            </div>
          )}

          {activeTab === 'netlify' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-600">
                Netlify is another excellent free host. You can deploy either with Drag & Drop or Git:
              </p>

              <div className="space-y-3 text-xs text-slate-700">
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                  <h5 className="font-bold text-slate-900 mb-1">Drag-and-Drop Deployment:</h5>
                  <ol className="list-decimal pl-5 space-y-1">
                    <li>Run <code>npm run build</code> on your computer to generate the production <code>dist</code> folder.</li>
                    <li>Go to <a href="https://app.netlify.com/drop" target="_blank" rel="noreferrer" className="text-blue-600 underline">netlify.com/drop</a>.</li>
                    <li>Drag the <code>dist</code> folder into the browser window.</li>
                    <li>Your website is immediately published with a free <code>.netlify.app</code> address!</li>
                  </ol>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'products' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">Where Product Data is Stored</h4>
                  <p className="text-xs text-slate-500">No database required! All products are in one clean TypeScript file:</p>
                </div>
                <button
                  onClick={handleExportJSON}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Catalog as JSON</span>
                </button>
              </div>

              <div className="p-3 bg-slate-900 text-slate-100 rounded-xl font-mono text-xs overflow-x-auto space-y-1">
                <p className="text-emerald-400">// File path: src/data/products.ts</p>
                <p>export const PRODUCTS: Product[] = [</p>
                <p className="pl-4">{"{"}</p>
                <p className="pl-8 text-blue-300">id: 'phone-01',</p>
                <p className="pl-8 text-blue-300">name: 'Titanium Pro Flagship 5G',</p>
                <p className="pl-8 text-blue-300">category: 'smartphones',</p>
                <p className="pl-8 text-amber-300">price: 145000, // Change price anytime</p>
                <p className="pl-8 text-slate-400">inStock: true,</p>
                <p className="pl-4">{"},"}</p>
                <p>];</p>
              </div>

              <div className="text-xs text-slate-600 space-y-1">
                <p>• To <strong>change a price</strong>: simply edit the <code>price: 145000</code> number.</p>
                <p>• To <strong>add a new product</strong>: copy any block, change the name, image URL and specifications.</p>
                <p>• To <strong>mark an item out of stock</strong>: change <code>inStock: false</code>.</p>
              </div>
            </div>
          )}

          {activeTab === 'whatsapp' && (
            <div className="space-y-4">
              <h4 className="font-bold text-slate-900 text-sm">How to Permanently Update Your WhatsApp Number</h4>
              <p className="text-xs text-slate-600">
                You can change it temporarily in the UI settings, or permanently in the configuration file before deploying:
              </p>

              <div className="p-4 bg-slate-900 text-slate-100 rounded-xl font-mono text-xs space-y-2">
                <p className="text-emerald-400">// File path: src/config/storeConfig.ts</p>
                <p>export const DEFAULT_STORE_CONFIG = {"{"}</p>
                <p className="pl-4 text-blue-300">storeName: 'SelimTech Store',</p>
                <p className="pl-4 text-amber-300 font-bold">whatsappNumber: 'YOUR_PHONE_NUMBER_HERE',</p>
                <p className="pl-4 text-slate-400">currencySymbol: 'ETB ',</p>
                <p>{"}"};</p>
              </div>

              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 space-y-1">
                <p className="font-bold">Important phone format tip:</p>
                <p>
                  Always use digits only with country code, without '+' or spaces. For example, if your phone is <code>+1 555-123-4567</code>, enter <code>15551234567</code>.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Current WhatsApp: <strong className="text-slate-800">{config.displayWhatsApp || config.whatsappNumber}</strong>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl transition-colors"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
