import React, { useState, useEffect, useMemo } from 'react';
import { 
  Navbar 
} from './components/Navbar';
import { 
  Hero 
} from './components/Hero';
import { 
  CategoryBar 
} from './components/CategoryBar';
import { 
  SpecialOffersBanner 
} from './components/SpecialOffersBanner';
import { 
  ProductCard 
} from './components/ProductCard';
import { 
  ProductDetailsModal 
} from './components/ProductDetailsModal';
import { 
  CartDrawer 
} from './components/CartDrawer';
import { 
  WhatsAppSettingsModal 
} from './components/WhatsAppSettingsModal';
import { 
  PublishingGuideModal 
} from './components/PublishingGuideModal';
import { 
  AboutUs 
} from './components/AboutUs';
import { 
  ContactSection 
} from './components/ContactSection';
import { 
  Footer 
} from './components/Footer';

import { 
  Product, 
  ProductCategory, 
  CartItem, 
  StoreConfig 
} from './types/store';
import { 
  PRODUCTS, 
  CATEGORIES 
} from './data/products';
import { 
  getActiveStoreConfig, 
  saveActiveStoreConfig 
} from './config/storeConfig';
import { 
  SlidersHorizontal, 
  Search, 
  RotateCcw, 
  Sparkles, 
  Flame, 
  Check, 
  ArrowRight,
  Filter
} from 'lucide-react';

export default function App() {
  // Store Config State (with live localStorage syncing)
  const [config, setConfig] = useState<StoreConfig>(getActiveStoreConfig);

  // Cart State (with localStorage persistence)
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('selimtech_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('selimtech_cart', JSON.stringify(cart));
    } catch (e) {
      console.error('Failed to save cart to localStorage', e);
    }
  }, [cart]);

  // Navigation State
  const [activeTab, setActiveTab] = useState<'home' | 'catalog' | 'offers' | 'about' | 'contact'>('home');
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [brandFilter, setBrandFilter] = useState('all');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');
  const [inStockOnly, setInStockOnly] = useState(false);
  const [priceMax, setPriceMax] = useState<number>(400000);

  // Modals State
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isGuideOpen, setIsGuideOpen] = useState(false);

  // Save config handler
  const handleSaveConfig = (updated: Partial<StoreConfig>) => {
    const saved = saveActiveStoreConfig(updated);
    setConfig(saved);
  };

  // Add to cart
  const handleAddToCart = (product: Product, quantity: number = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
  };

  // Update cart item quantity
  const handleUpdateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveCartItem(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  // Remove from cart
  const handleRemoveCartItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  // Clear cart
  const handleClearCart = () => {
    setCart([]);
  };

  // Unique brands list for filter
  const allBrands = useMemo(() => {
    const brands = new Set<string>();
    PRODUCTS.forEach((p) => brands.add(p.brand));
    return Array.from(brands).sort();
  }, []);

  // Category counts
  const categoryCounts = useMemo(() => {
    const counts: Record<ProductCategory, number> = {
      all: PRODUCTS.length,
      smartphones: 0,
      laptops: 0,
      desktops: 0,
      smart_tvs: 0,
      headphones: 0,
      smartwatches: 0,
      chargers_accessories: 0,
      other_electronics: 0,
    };
    PRODUCTS.forEach((p) => {
      if (counts[p.category] !== undefined) {
        counts[p.category]++;
      }
    });
    return counts;
  }, []);

  // Filtered and Sorted Products
  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((product) => {
      // Category filter
      if (selectedCategory !== 'all' && product.category !== selectedCategory) {
        return false;
      }

      // Special offers tab filter
      if (activeTab === 'offers' && !product.isSpecialOffer && !product.discountPercentage) {
        return false;
      }

      // Brand filter
      if (brandFilter !== 'all' && product.brand !== brandFilter) {
        return false;
      }

      // Price filter
      if (product.price > priceMax) {
        return false;
      }

      // In Stock filter
      if (inStockOnly && !product.inStock) {
        return false;
      }

      // Search Query filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const inName = product.name.toLowerCase().includes(query);
        const inBrand = product.brand.toLowerCase().includes(query);
        const inCategory = product.categoryLabel.toLowerCase().includes(query);
        const inDesc = product.description.toLowerCase().includes(query);
        const inSpecs = Object.values(product.specifications).some((val) =>
          val.toLowerCase().includes(query)
        );
        if (!inName && !inBrand && !inCategory && !inDesc && !inSpecs) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      // Default: featured first
      if (a.isFeatured && !b.isFeatured) return -1;
      if (!a.isFeatured && b.isFeatured) return 1;
      return 0;
    });
  }, [selectedCategory, activeTab, brandFilter, priceMax, inStockOnly, searchQuery, sortBy]);

  // Reset all filters
  const handleResetFilters = () => {
    setSelectedCategory('all');
    setSearchQuery('');
    setBrandFilter('all');
    setPriceMax(400000);
    setSortBy('featured');
    setInStockOnly(false);
  };

  const featuredDealProduct = useMemo(() => {
    return PRODUCTS.find((p) => p.id === 'sp-01') || PRODUCTS[0];
  }, []);

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Primary Navigation Bar */}
      <Navbar
        config={config}
        cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenGuide={() => setIsGuideOpen(true)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        
        {/* VIEW: HOME */}
        {activeTab === 'home' && (
          <div>
            <Hero
              config={config}
              onExploreCatalog={() => {
                setActiveTab('catalog');
                setSelectedCategory('all');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onViewOffers={() => {
                setActiveTab('offers');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />

            <CategoryBar
              selectedCategory={selectedCategory}
              onSelectCategory={(cat) => {
                setSelectedCategory(cat);
                setActiveTab('catalog');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              productCounts={categoryCounts}
            />

            <SpecialOffersBanner
              config={config}
              featuredDealProduct={featuredDealProduct}
              onOpenProduct={(p) => setSelectedProduct(p)}
            />

            {/* Featured Collection Section */}
            <section className="py-12 lg:py-16 max-w-7xl mx-auto px-4 sm:px-6">
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold text-blue-600 uppercase tracking-wider mb-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Handpicked Premium Hardware</span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-950 tracking-tight">
                    Featured Electronics & Best Sellers
                  </h2>
                </div>

                <button
                  onClick={() => {
                    setActiveTab('catalog');
                    setSelectedCategory('all');
                  }}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:text-blue-700 transition-colors group"
                >
                  <span>View All {PRODUCTS.length} Products</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>

              {/* 3-Column Desktop Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
                {PRODUCTS.filter((p) => p.isFeatured).slice(0, 6).map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    config={config}
                    onOpenDetails={(p) => setSelectedProduct(p)}
                    onAddToCart={(p) => handleAddToCart(p, 1)}
                  />
                ))}
              </div>
            </section>
          </div>
        )}

        {/* VIEW: CATALOG or OFFERS */}
        {(activeTab === 'catalog' || activeTab === 'offers') && (
          <div className="py-8 bg-slate-50/50">
            <CategoryBar
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
              productCounts={categoryCounts}
            />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
              {/* Header Title & Breadcrumb */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-950 tracking-tight">
                    {activeTab === 'offers' ? 'Special Offers & Discounted Tech' : 'Electronics Catalog'}
                  </h1>
                  <p className="text-xs text-slate-500 mt-1">
                    Showing <strong className="text-slate-800">{filteredProducts.length}</strong> items in{' '}
                    <span className="text-blue-600 font-semibold">
                      {CATEGORIES.find((c) => c.id === selectedCategory)?.label || 'All Categories'}
                    </span>
                  </p>
                </div>

                {/* Reset Filters Quick Button if active */}
                {(selectedCategory !== 'all' || brandFilter !== 'all' || searchQuery || inStockOnly) && (
                  <button
                    onClick={handleResetFilters}
                    className="self-start sm:self-auto flex items-center gap-1.5 px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold rounded-lg transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reset All Filters</span>
                  </button>
                )}
              </div>

              {/* Filter Controls Toolbar */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
                
                {/* Left: Brand filter & In-Stock toggle */}
                <div className="flex flex-wrap items-center gap-3">
                  <div className="flex items-center gap-1.5 text-xs text-slate-600">
                    <Filter className="w-3.5 h-3.5 text-slate-400" />
                    <span className="font-semibold text-slate-700">Brand:</span>
                    <select
                      value={brandFilter}
                      onChange={(e) => setBrandFilter(e.target.value)}
                      className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 outline-none focus:border-blue-500"
                    >
                      <option value="all">All Brands</option>
                      {allBrands.map((b) => (
                        <option key={b} value={b}>{b}</option>
                      ))}
                    </select>
                  </div>

                  {/* In-Stock Only Toggle */}
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700 hover:text-slate-900 select-none">
                    <input
                      type="checkbox"
                      checked={inStockOnly}
                      onChange={(e) => setInStockOnly(e.target.checked)}
                      className="w-3.5 h-3.5 rounded text-blue-600 focus:ring-blue-500"
                    />
                    <span>In-Stock Only</span>
                  </label>
                </div>

                {/* Right: Max Price & Sort By */}
                <div className="flex flex-wrap items-center gap-3">
                  <div className="flex items-center gap-2 text-xs text-slate-600">
                    <span>Max Price:</span>
                    <span className="font-bold text-slate-900 tabular-nums">
                      {config.currencySymbol}{priceMax.toLocaleString()}
                    </span>
                    <input
                      type="range"
                      min={5000}
                      max={400000}
                      step={5000}
                      value={priceMax}
                      onChange={(e) => setPriceMax(Number(e.target.value))}
                      className="w-24 sm:w-32 accent-blue-600 cursor-pointer"
                    />
                  </div>

                  <div className="flex items-center gap-1.5 text-xs text-slate-600">
                    <span className="font-semibold text-slate-700">Sort:</span>
                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value as any)}
                      className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 outline-none focus:border-blue-500"
                    >
                      <option value="featured">Featured First</option>
                      <option value="price-asc">Price: Low to High</option>
                      <option value="price-desc">Price: High to Low</option>
                      <option value="rating">Highest Rated</option>
                    </select>
                  </div>
                </div>

              </div>

              {/* Product Grid */}
              {filteredProducts.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
                  {filteredProducts.map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      config={config}
                      onOpenDetails={(p) => setSelectedProduct(p)}
                      onAddToCart={(p) => handleAddToCart(p, 1)}
                    />
                  ))}
                </div>
              ) : (
                <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4 max-w-md mx-auto">
                  <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
                    <Search className="w-7 h-7" />
                  </div>
                  <h3 className="font-bold text-base text-slate-900">No electronics match your search</h3>
                  <p className="text-xs text-slate-500">
                    Try broadening your filters, searching for a different keyword, or resetting your criteria.
                  </p>
                  <button
                    onClick={handleResetFilters}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl transition-colors"
                  >
                    Reset All Filters
                  </button>
                </div>
              )}

            </div>
          </div>
        )}

        {/* VIEW: ABOUT US */}
        {activeTab === 'about' && (
          <AboutUs
            config={config}
            onExploreCatalog={() => {
              setActiveTab('catalog');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {/* VIEW: CONTACT */}
        {activeTab === 'contact' && (
          <ContactSection config={config} />
        )}

      </main>

      {/* Footer */}
      <Footer
        config={config}
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          setActiveTab('catalog');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenGuide={() => setIsGuideOpen(true)}
      />

      {/* Floating Quick WhatsApp Button on Mobile/Tablet */}
      <a
        href={`https://wa.me/${config.whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`Hello ${config.storeName}! 👋 I have a question about your electronics catalog.`)}`}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-5 right-5 z-40 bg-emerald-600 hover:bg-emerald-500 text-white p-3.5 rounded-full shadow-2xl flex items-center justify-center transition-transform hover:scale-110 active:scale-95 group"
        aria-label="Direct WhatsApp Chat"
      >
        <div className="relative">
          <svg className="w-6 h-6 fill-white" viewBox="0 0 24 24">
            <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
          </svg>
        </div>
      </a>

      {/* Product Details Modal */}
      <ProductDetailsModal
        product={selectedProduct}
        config={config}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={(p, qty) => handleAddToCart(p, qty)}
      />

      {/* Shopping Bag Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        config={config}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
        onExploreProducts={() => {
          setActiveTab('catalog');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* WhatsApp Number & Store Settings Modal */}
      <WhatsAppSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        config={config}
        onSaveConfig={handleSaveConfig}
      />

      {/* Publishing and Free Hosting Guide Modal */}
      <PublishingGuideModal
        isOpen={isGuideOpen}
        onClose={() => setIsGuideOpen(false)}
        config={config}
      />
    </div>
  );
}
