import React, { useState } from 'react';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  MessageCircle, 
  Send, 
  CheckCircle2, 
  ChevronDown,
  HelpCircle,
  ShieldCheck
} from 'lucide-react';
import { StoreConfig } from '../types/store';

interface ContactSectionProps {
  config: StoreConfig;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ config }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [subject, setSubject] = useState('Product Inquiry');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  // FAQ open state
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const cleanWhatsApp = config.whatsappNumber.replace(/[^0-9]/g, '');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  const handleSendViaWhatsApp = () => {
    const text = `Hello ${config.storeName}! 👋\nName: ${name}\nEmail: ${email}\nPhone: ${phone}\nSubject: ${subject}\n\nMessage: ${message}`;
    const url = `https://wa.me/${cleanWhatsApp}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const faqs = [
    {
      q: 'How does ordering via WhatsApp work at SelimTech?',
      a: 'Simply click "Order via WhatsApp" on any product or from your cart. A pre-filled WhatsApp message containing the exact product name, price, quantity, and specifications opens instantly in your WhatsApp. Our customer support team confirms stock and sends you payment and delivery details.',
    },
    {
      q: 'Do your products include official warranty?',
      a: 'Yes, 100%! All our electronics are brand new, original, and covered by official manufacturer warranties ranging from 12 to 24 months depending on the brand (Apple, Samsung, Sony, Dell, LG, Anker, etc.).',
    },
    {
      q: 'What payment options do you accept?',
      a: 'We offer flexible payment options including Cash on Delivery (COD) for eligible cities, Bank Transfers, Credit/Debit cards, and Mobile Money depending on your region. All confirmed on WhatsApp prior to dispatch.',
    },
    {
      q: 'How fast is delivery?',
      a: 'Standard orders within the metropolitan area are delivered within 24 hours. Regional and express shipping takes 1 to 3 business days. Orders exceeding ' + config.currencySymbol + config.freeShippingThreshold.toLocaleString() + ' qualify for Free Express Delivery.',
    },
    {
      q: 'Can I visit your physical showroom?',
      a: 'Yes! You are welcome to visit our showroom at ' + config.address + ', ' + config.cityCountry + ' during business hours to inspect devices in person and test demo units.',
    },
  ];

  return (
    <div className="bg-slate-50 py-12 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-16">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">
            We Are Here To Help
          </span>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            Contact SelimTech Store
          </h2>
          <p className="text-sm text-slate-600">
            Have questions about a product, warranty, or bulk corporate purchase? Connect with our technical specialists directly.
          </p>
        </div>

        {/* Contact Information & Interactive Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Direct Channels & Physical Store */}
          <div className="lg:col-span-5 space-y-5">
            {/* Direct WhatsApp Callout */}
            <div className="bg-emerald-600 text-white p-6 rounded-2xl shadow-lg space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
                  <MessageCircle className="w-5 h-5 fill-white" />
                </div>
                <div>
                  <h3 className="font-bold text-base">Instant WhatsApp Desk</h3>
                  <p className="text-xs text-emerald-100">Average response time: &lt; 15 mins</p>
                </div>
              </div>

              <p className="text-xs text-emerald-50 leading-relaxed">
                Connect with our product specialists on WhatsApp for instant price quotes, stock checks, or custom bundled packages.
              </p>

              <a
                href={`https://wa.me/${cleanWhatsApp}?text=${encodeURIComponent(`Hello ${config.storeName}! I would like to speak with a customer sales representative.`)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 bg-white text-emerald-700 hover:bg-emerald-50 text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Chat on {config.displayWhatsApp || config.whatsappNumber}</span>
              </a>
            </div>

            {/* Store Information Cards */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4 text-xs text-slate-700">
              <h4 className="font-bold text-sm text-slate-900">Flagship Showroom & Operations</h4>

              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-slate-900">{config.storeName} Headquarters</p>
                  <p className="text-slate-500">{config.address}</p>
                  <p className="text-slate-500">{config.cityCountry}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-slate-900">Working Hours</p>
                  <p className="text-slate-500">{config.openingHours}</p>
                  <p className="text-slate-500">Sunday: 10:00 AM – 5:00 PM</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-slate-900">Phone Support</p>
                  <p className="text-slate-500">{config.supportPhone}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-slate-900">Direct Email</p>
                  <p className="text-slate-500">{config.supportEmail}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Contact Message Form */}
          <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs">
            <h3 className="font-bold text-base text-slate-900 mb-1">Send Us a Direct Message</h3>
            <p className="text-xs text-slate-500 mb-5">
              Fill out this form and either submit online or transfer your inquiry directly to our WhatsApp chat.
            </p>

            {isSubmitted ? (
              <div className="p-6 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-3">
                <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h4 className="font-bold text-base text-emerald-900">Message Received!</h4>
                <p className="text-xs text-emerald-700 max-w-sm mx-auto">
                  Thank you, <strong>{name}</strong>. Our team will review your message and reply via email or phone within 2 hours.
                </p>
                <div className="pt-2 flex flex-col sm:flex-row justify-center gap-2">
                  <button
                    onClick={handleSendViaWhatsApp}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Also Send to WhatsApp for Faster Reply</span>
                  </button>
                  <button
                    onClick={() => {
                      setIsSubmitted(false);
                      setMessage('');
                    }}
                    className="px-4 py-2 bg-white border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl hover:bg-slate-50"
                  >
                    Send Another Message
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Your Full Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Alex Morgan"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Your Email Address *</label>
                    <input
                      type="email"
                      required
                      placeholder="alex@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number (Optional)</label>
                    <input
                      type="tel"
                      placeholder="+1 (555) 000-0000"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Inquiry Subject</label>
                    <select
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none bg-white"
                    >
                      <option value="Product Availability & Stock">Product Availability & Stock</option>
                      <option value="WhatsApp Order Inquiry">WhatsApp Order Inquiry</option>
                      <option value="Warranty & Technical Support">Warranty & Technical Support</option>
                      <option value="Bulk / Corporate Hardware Purchase">Bulk / Corporate Purchase</option>
                      <option value="General Question">General Question</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Your Message *</label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Tell us what product you are interested in or questions you have..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
                  />
                </div>

                <div className="pt-2 flex flex-col sm:flex-row gap-3">
                  <button
                    type="submit"
                    className="flex-1 py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Submit Message</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSendViaWhatsApp}
                    className="py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <MessageCircle className="w-3.5 h-3.5 fill-white/20" />
                    <span>Send directly on WhatsApp</span>
                  </button>
                </div>
              </form>
            )}
          </div>

        </div>

        {/* FAQ Accordion Section */}
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
          <div className="text-center max-w-xl mx-auto space-y-1">
            <h3 className="font-bold text-xl text-slate-900">Frequently Asked Questions</h3>
            <p className="text-xs text-slate-500">Everything you need to know about shopping at SelimTech Store</p>
          </div>

          <div className="divide-y divide-slate-100 max-w-3xl mx-auto">
            {faqs.map((faq, index) => {
              const isOpen = openFaq === index;
              return (
                <div key={index} className="py-3">
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : index)}
                    className="w-full flex items-center justify-between text-left py-2 gap-4 group"
                  >
                    <span className="font-semibold text-sm text-slate-800 group-hover:text-blue-600 transition-colors">
                      {faq.q}
                    </span>
                    <ChevronDown className={`w-4 h-4 text-slate-400 shrink-0 transition-transform ${isOpen ? 'rotate-180 text-blue-600' : ''}`} />
                  </button>
                  {isOpen && (
                    <p className="text-xs text-slate-600 pt-1 pb-2 leading-relaxed">
                      {faq.a}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
};
