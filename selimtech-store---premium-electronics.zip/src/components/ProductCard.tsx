import React, { useState } from 'react';
import { 
  Star, 
  MessageCircle, 
  ShoppingBag, 
  Check, 
  Eye, 
  Sparkles,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { Product, StoreConfig } from '../types/store';
import { generateSingleProductWhatsAppLink } from '../utils/whatsapp';

interface ProductCardProps {
  product: Product;
  config: StoreConfig;
  onOpenDetails: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  config,
  onOpenDetails,
  onAddToCart,
}) => {
  const [isAdded, setIsAdded] = useState(false);
  const [imageError, setImageError] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 1600);
  };

  const handleWhatsAppOrder = (e: React.MouseEvent) => {
    e.stopPropagation();
    const url = generateSingleProductWhatsAppLink(product, 1, config);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div
      onClick={() => onOpenDetails(product)}
      className="group relative bg-white rounded-2xl border border-slate-200 hover:border-blue-400/80 shadow-xs hover:shadow-lg transition-all duration-200 flex flex-col overflow-hidden cursor-pointer"
    >
      {/* Top Image Container */}
      <div className="relative aspect-[4/3] w-full bg-slate-100 overflow-hidden">
        {!imageError ? (
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
            referrerPolicy="no-referrer"
            onError={() => setImageError(true)}
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-slate-100 to-slate-200 flex flex-col items-center justify-center p-4 text-center">
            <Zap className="w-8 h-8 text-blue-600 mb-1" />
            <span className="text-xs font-semibold text-slate-700">{product.brand}</span>
            <span className="text-[11px] text-slate-500">{product.categoryLabel}</span>
          </div>
        )}

        {/* Badges / Discount */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 items-start">
          {product.discountPercentage && (
            <span className="bg-rose-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-sm">
              SAVE {product.discountPercentage}%
            </span>
          )}
          {product.isFeatured && (
            <span className="bg-slate-900/90 text-amber-300 text-[10px] font-semibold px-2 py-0.5 rounded backdrop-blur-xs flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5" />
              Featured
            </span>
          )}
        </div>

        {/* Quick View Button on Hover */}
        <div className="absolute inset-0 bg-slate-950/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
          <span className="px-3 py-1.5 bg-white/95 text-slate-900 text-xs font-semibold rounded-lg shadow-md flex items-center gap-1.5 transform translate-y-2 group-hover:translate-y-0 transition-transform">
            <Eye className="w-3.5 h-3.5" />
            Quick View
          </span>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div className="space-y-1.5">
          {/* Category & Brand Metadata (unboxed clean text) */}
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span className="font-semibold text-blue-600">{product.brand}</span>
            <span aria-hidden="true">·</span>
            <span>{product.categoryLabel}</span>
          </div>

          {/* Product Title */}
          <h3 className="text-sm sm:text-base font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-2 leading-snug">
            {product.name}
          </h3>

          {/* Short description */}
          <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
            {product.shortDescription}
          </p>

          {/* Rating */}
          <div className="flex items-center gap-1.5 pt-1">
            <div className="flex items-center text-amber-500">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            </div>
            <span className="text-xs font-bold text-slate-800">{product.rating}</span>
            <span className="text-xs text-slate-400">({product.reviewsCount})</span>
            <span className="text-xs text-emerald-600 ml-auto flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" />
              Verified
            </span>
          </div>
        </div>

        {/* Pricing and Stock */}
        <div className="pt-3 border-t border-slate-100 mt-3 space-y-3">
          <div className="flex items-baseline justify-between">
            <div className="flex items-baseline gap-2">
              <span className="text-lg font-extrabold text-slate-950 tabular-nums">
                {config.currencySymbol}{product.price.toLocaleString()}
              </span>
              {product.originalPrice && (
                <span className="text-xs text-slate-400 line-through tabular-nums">
                  {config.currencySymbol}{product.originalPrice.toLocaleString()}
                </span>
              )}
            </div>

            <span className={`text-[11px] font-medium ${
              product.inStock ? 'text-emerald-600' : 'text-slate-400'
            }`}>
              {product.inStock ? (product.stockCount ? `${product.stockCount} in stock` : 'In Stock') : 'Backorder'}
            </span>
          </div>

          {/* Action Buttons: WhatsApp Order (Primary) & Add to Cart (Secondary) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <button
              onClick={handleWhatsAppOrder}
              className="w-full py-2 px-2.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-1.5 shadow-xs whitespace-nowrap"
              title="Order this product directly on WhatsApp"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-white/20 shrink-0" />
              <span className="truncate">Order via WhatsApp</span>
            </button>

            <button
              onClick={handleAddToCart}
              className={`w-full py-2 px-2.5 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1.5 whitespace-nowrap ${
                isAdded
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200'
              }`}
            >
              {isAdded ? (
                <>
                  <Check className="w-3.5 h-3.5 shrink-0" />
                  <span>Added!</span>
                </>
              ) : (
                <>
                  <ShoppingBag className="w-3.5 h-3.5 shrink-0" />
                  <span>Add to Cart</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
