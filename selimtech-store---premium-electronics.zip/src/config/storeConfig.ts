import { StoreConfig } from '../types/store';

/**
 * ========================================================
 * SELIMTECH STORE - CONFIGURATION
 * ========================================================
 * You can customize your store details, especially your WhatsApp
 * phone number.
 * 
 * WhatsApp format: Country code + number without '+' or spaces.
 * Example for US/Canada: "15551234567"
 * Example for UK: "447911123456"
 * Example for Ethiopia: "251911234567"
 * Example for Nigeria: "2348012345678"
 * Example for UAE: "971501234567"
 */

export const DEFAULT_STORE_CONFIG: StoreConfig = {
  storeName: 'SelimTech Store',
  tagline: 'Premium Electronics & Smart Technology',
  whatsappNumber: '251911234567', // Ethiopian WhatsApp placeholder format (+251)
  displayWhatsApp: '+251 91 123 4567',
  supportEmail: 'contact@selimtechstore.com',
  supportPhone: '+251 91 123 4567',
  address: 'Bole Medhanialem, Edna Mall Area, Suite 402',
  cityCountry: 'Addis Ababa, Ethiopia',
  openingHours: 'Mon - Sat: 8:30 AM – 7:30 PM (EAT)',
  currencySymbol: 'ETB ',
  currencyCode: 'ETB',
  freeShippingThreshold: 15000,
};

// Local storage key for dynamic user updates without rebuilding
export const STORE_CONFIG_STORAGE_KEY = 'selimtech_store_custom_config';

export function getActiveStoreConfig(): StoreConfig {
  if (typeof window === 'undefined') return DEFAULT_STORE_CONFIG;
  try {
    const saved = localStorage.getItem(STORE_CONFIG_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      // Ensure currency is converted to ETB if previously cached as USD/$
      if (parsed.currencySymbol === '$' || parsed.currencyCode === 'USD') {
        parsed.currencySymbol = 'ETB ';
        parsed.currencyCode = 'ETB';
        parsed.freeShippingThreshold = 15000;
      }
      return { ...DEFAULT_STORE_CONFIG, ...parsed };
    }
  } catch {
    // fallback
  }
  return DEFAULT_STORE_CONFIG;
}

export function saveActiveStoreConfig(config: Partial<StoreConfig>): StoreConfig {
  const current = getActiveStoreConfig();
  const updated = { ...current, ...config };
  try {
    localStorage.setItem(STORE_CONFIG_STORAGE_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to save config to localStorage', e);
  }
  return updated;
}
