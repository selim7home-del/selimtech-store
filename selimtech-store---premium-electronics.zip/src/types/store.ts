export type ProductCategory =
  | 'all'
  | 'smartphones'
  | 'laptops'
  | 'desktops'
  | 'smart_tvs'
  | 'headphones'
  | 'smartwatches'
  | 'chargers_accessories'
  | 'other_electronics';

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  categoryLabel: string;
  brand: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  inStock: boolean;
  stockCount?: number;
  isFeatured?: boolean;
  isSpecialOffer?: boolean;
  discountPercentage?: number;
  image: string;
  additionalImages?: string[];
  shortDescription: string;
  description: string;
  specifications: Record<string, string>;
  keyFeatures: string[];
  warranty: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
}

export interface StoreConfig {
  storeName: string;
  tagline: string;
  whatsappNumber: string; // e.g., "1234567890" (country code + number without plus or special chars)
  displayWhatsApp: string; // e.g., "+1 (234) 567-890"
  supportEmail: string;
  supportPhone: string;
  address: string;
  cityCountry: string;
  openingHours: string;
  currencySymbol: string;
  currencyCode: string;
  freeShippingThreshold: number;
}
