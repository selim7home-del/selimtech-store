import React from 'react';
import { 
  MessageCircle, 
  ShieldCheck, 
  Mail, 
  Phone, 
  MapPin, 
  Heart,
  Globe,
  Settings,
  BookOpen
} from 'lucide-react';
import { StoreConfig, ProductCategory } from '../types/store';

interface FooterProps {
  config: StoreConfig;
  onSelectCategory: (category: ProductCategory) => void;
  onSelectTab: (tab: 'home' | 'catalog' | 'offers' | 'about' | 'contact') => void;
  onOpenSettings: () => void;
  onOpenGuide: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  config,
  onSelectCategory,
  onSelectTab,
  onOpenSettings,
  onOpenGuide,
}) => {
  const cleanWhatsApp = config.whatsappNumber.replace(/[^0-9]/g, '');

  return (
    <footer className="bg-slate-950 text-slate-400 border-t border-slate-900 pt-12 pb-8 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-12">
        
        {/* Main 4-Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8">
          
          {/* Col 1: Brand & WhatsApp Order CTA */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-extrabold text-base">
                S
              </div>
              <span className="text-lg font-bold text-white tracking-tight">
                SelimTech <span className="text-blue-500 font-semibold">Store</span>
              </span>
            </div>

            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              Your trusted destination for premium electronics. Verified genuine smartphones, pro laptops, 4K Smart TVs, and audio gear with instant WhatsApp ordering.
            </p>

            {/* Quick WhatsApp Support Pill */}
            <div className="pt-1">
              <a
                href={`https://wa.me/${cleanWhatsApp}?text=${encodeURIComponent(`Hello ${config.storeName}! I am messaging you from your website footer.`)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-3.5 py-2 bg-emerald-600/90 hover:bg-emerald-600 text-white rounded-xl text-xs font-semibold transition-colors"
              >
                <MessageCircle className="w-4 h-4 fill-white/20" />
                <span>WhatsApp: {config.displayWhatsApp || config.whatsappNumber}</span>
              </a>
            </div>

            <div className="flex items-center gap-2 text-[11px] text-slate-500 pt-2">
              <button
                onClick={onOpenSettings}
                className="hover:text-slate-300 flex items-center gap-1 transition-colors underline"
              >
                <Settings className="w-3 h-3" />
                <span>Change Store WhatsApp Number</span>
              </button>
            </div>
          </div>

          {/* Col 2: Categories */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-bold text-sm text-white tracking-wider uppercase text-[11px]">
              Categories
            </h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => onSelectCategory('smartphones')}
                  className="hover:text-white transition-colors"
                >
                  Smartphones & 5G
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('laptops')}
                  className="hover:text-white transition-colors"
                >
                  Pro Laptops & Ultrabooks
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('desktops')}
                  className="hover:text-white transition-colors"
                >
                  Desktop Computers & Rigs
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('smart_tvs')}
                  className="hover:text-white transition-colors"
                >
                  4K & 8K Smart TVs
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('headphones')}
                  className="hover:text-white transition-colors"
                >
                  Headphones & Audiophile Gear
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('smartwatches')}
                  className="hover:text-white transition-colors"
                >
                  Smartwatches & Fitness
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('chargers_accessories')}
                  className="hover:text-white transition-colors"
                >
                  GaN Chargers & Cables
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Navigation & Free Guide */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-bold text-sm text-white tracking-wider uppercase text-[11px]">
              Quick Links
            </h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onSelectTab('home')} className="hover:text-white transition-colors">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('catalog')} className="hover:text-white transition-colors">
                  Product Catalog
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('offers')} className="hover:text-white transition-colors">
                  Special Offers
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('about')} className="hover:text-white transition-colors">
                  About Us
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('contact')} className="hover:text-white transition-colors">
                  Contact & Support
                </button>
              </li>
              <li className="pt-2">
                <button 
                  onClick={onOpenGuide} 
                  className="text-blue-400 hover:text-blue-300 font-semibold flex items-center gap-1 transition-colors"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>Free Hosting Guide</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Store Info & Operating Hours */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-bold text-sm text-white tracking-wider uppercase text-[11px]">
              Store & Operations
            </h4>
            <div className="space-y-2 text-slate-400">
              <p className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-blue-500 shrink-0 mt-0.5" />
                <span>{config.address}, {config.cityCountry}</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                <span>{config.supportPhone}</span>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                <span>{config.supportEmail}</span>
              </p>
              <p className="text-[11px] text-slate-500 pt-1">
                {config.openingHours}
              </p>
            </div>
          </div>

        </div>

        {/* Bottom Bar: Copyright & Guarantee */}
        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <p>© {new Date().getFullYear()} {config.storeName}. All rights reserved. 100% genuine consumer electronics.</p>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
              Verified Distributor Hardware
            </span>
            <span>·</span>
            <span>Worldwide Delivery</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
