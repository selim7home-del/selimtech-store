import React from 'react';
import { 
  ShoppingBag, 
  Search, 
  MessageCircle, 
  Menu, 
  X, 
  Settings, 
  BookOpen, 
  PhoneCall, 
  ShieldCheck,
  Check
} from 'lucide-react';
import { StoreConfig } from '../types/store';

interface NavbarProps {
  config: StoreConfig;
  cartCount: number;
  onOpenCart: () => void;
  onOpenSettings: () => void;
  onOpenGuide: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  activeTab: 'home' | 'catalog' | 'offers' | 'about' | 'contact';
  onSelectTab: (tab: 'home' | 'catalog' | 'offers' | 'about' | 'contact') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  config,
  cartCount,
  onOpenCart,
  onOpenSettings,
  onOpenGuide,
  searchQuery,
  onSearchChange,
  activeTab,
  onSelectTab,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [isSearchExpanded, setIsSearchExpanded] = React.useState(false);

  const isDefaultNumber = config.whatsappNumber === '1234567890';

  const navItems: { id: 'home' | 'catalog' | 'offers' | 'about' | 'contact'; label: string }[] = [
    { id: 'home', label: 'Home' },
    { id: 'catalog', label: 'All Products' },
    { id: 'offers', label: 'Special Offers' },
    { id: 'about', label: 'About Us' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNavClick = (id: 'home' | 'catalog' | 'offers' | 'about' | 'contact') => {
    onSelectTab(id);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      {/* Top Notification / WhatsApp Bar */}
      <div className="bg-slate-900 text-slate-300 text-xs py-1.5 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 truncate">
            <span className="inline-flex items-center gap-1.5 text-blue-400 font-medium shrink-0">
              <ShieldCheck className="w-3.5 h-3.5" />
              100% Genuine Electronics & Official Warranty
            </span>
            <span className="hidden md:inline text-slate-500">|</span>
            <span className="hidden md:inline text-slate-400 truncate">
              Order directly via WhatsApp for fast priority dispatch!
            </span>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {/* WhatsApp Number indicator & quick test button */}
            <button
              onClick={onOpenSettings}
              className={`flex items-center gap-1 px-2 py-0.5 rounded text-xs transition-colors ${
                isDefaultNumber 
                  ? 'bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/40' 
                  : 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30'
              }`}
              title="Click to change WhatsApp number"
            >
              <Settings className="w-3 h-3" />
              <span>
                {isDefaultNumber ? 'Setup WhatsApp No.' : `WA: ${config.displayWhatsApp || config.whatsappNumber}`}
              </span>
            </button>

            <button
              onClick={onOpenGuide}
              className="hidden lg:flex items-center gap-1 text-slate-300 hover:text-white transition-colors"
              title="View free hosting & store editing guide"
            >
              <BookOpen className="w-3 h-3 text-blue-400" />
              <span>Free Hosting Guide</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar adhering to Top Bar Contract */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <a 
          href="#home"
          onClick={(e) => { e.preventDefault(); handleNavClick('home'); }}
          className="flex items-center gap-2.5 text-slate-950 font-extrabold text-xl tracking-tight whitespace-nowrap shrink-0 group"
        >
          <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white font-black text-lg shadow-sm group-hover:bg-blue-700 transition-colors">
            S
          </div>
          <span className="text-xl font-bold tracking-tight text-slate-900">
            SelimTech <span className="text-blue-600 font-semibold">Store</span>
          </span>
        </a>

        {/* Zone 2: Navigation Links (single-line, concise) */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-700">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`whitespace-nowrap shrink-0 transition-colors py-1 relative ${
                activeTab === item.id
                  ? 'text-blue-600 font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-blue-600'
                  : 'hover:text-slate-900'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: Search, Cart and Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Search Input on Desktop */}
          <div className="relative hidden md:block w-48 lg:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search phones, laptops..."
              value={searchQuery}
              onChange={(e) => {
                onSearchChange(e.target.value);
                if (activeTab !== 'catalog' && e.target.value.trim().length > 0) {
                  onSelectTab('catalog');
                }
              }}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-100 hover:bg-slate-50 focus:bg-white border border-transparent focus:border-blue-500 rounded-lg outline-none transition-all text-slate-800 placeholder-slate-400"
            >
            </input>
            {searchQuery && (
              <button 
                onClick={() => onSearchChange('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Cart Drawer Trigger */}
          <button
            onClick={onOpenCart}
            className="relative flex items-center justify-center w-10 h-10 rounded-lg text-slate-700 hover:text-blue-600 hover:bg-slate-100 transition-colors border border-slate-200"
            aria-label="View Shopping Cart"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 min-w-[20px] h-5 bg-blue-600 text-white text-[11px] font-bold rounded-full flex items-center justify-center px-1">
                {cartCount}
              </span>
            )}
          </button>

          {/* Primary WhatsApp Quick Chat Action */}
          <a
            href={`https://wa.me/${config.whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`Hello ${config.storeName}! I am interested in your electronics catalog.`)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors whitespace-nowrap shrink-0"
          >
            <MessageCircle className="w-4 h-4 fill-white/20" />
            <span>Chat on WhatsApp</span>
          </a>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden flex items-center justify-center w-10 h-10 rounded-lg text-slate-700 hover:bg-slate-100 transition-colors"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Search Bar */}
      <div className="md:hidden px-4 pb-3">
        <div className="relative w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Search phones, laptops, TVs, audio..."
            value={searchQuery}
            onChange={(e) => {
              onSearchChange(e.target.value);
              if (activeTab !== 'catalog' && e.target.value.trim().length > 0) {
                onSelectTab('catalog');
              }
            }}
            className="w-full pl-9 pr-3 py-2 text-sm bg-slate-100 focus:bg-white border border-transparent focus:border-blue-500 rounded-lg outline-none text-slate-800"
          />
          {searchQuery && (
            <button 
              onClick={() => onSearchChange('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-sm"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Mobile Drawer Navigation Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-5 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                activeTab === item.id
                  ? 'bg-blue-50 text-blue-600 font-semibold'
                  : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              {item.label}
            </button>
          ))}

          <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
            <button
              onClick={() => {
                onOpenSettings();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-between px-3 py-2 text-xs text-slate-600 hover:bg-slate-50 rounded-lg"
            >
              <span className="flex items-center gap-2">
                <Settings className="w-4 h-4 text-slate-400" />
                Change WhatsApp Number
              </span>
              <span className="text-slate-400 font-mono text-[11px]">{config.whatsappNumber}</span>
            </button>

            <button
              onClick={() => {
                onOpenGuide();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs text-blue-600 hover:bg-blue-50 rounded-lg font-medium"
            >
              <BookOpen className="w-4 h-4" />
              <span>How to Host for Free & Edit Catalog</span>
            </button>

            <a
              href={`https://wa.me/${config.whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`Hello ${config.storeName}! I am browsing your online catalog.`)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 mt-2 px-4 py-2.5 bg-emerald-600 text-white rounded-lg text-sm font-semibold hover:bg-emerald-700 transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Order / Inquire via WhatsApp</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
