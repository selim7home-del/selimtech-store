import React, { useState, useEffect } from 'react';
import { Flame, Clock, ArrowRight, MessageCircle, Sparkles } from 'lucide-react';
import { Product, StoreConfig } from '../types/store';
import { generateSingleProductWhatsAppLink } from '../utils/whatsapp';

interface SpecialOffersBannerProps {
  config: StoreConfig;
  featuredDealProduct: Product;
  onOpenProduct: (product: Product) => void;
}

export const SpecialOffersBanner: React.FC<SpecialOffersBannerProps> = ({
  config,
  featuredDealProduct,
  onOpenProduct,
}) => {
  // Countdown timer for flash sale (resets every 24 hours cleanly)
  const [timeLeft, setTimeLeft] = useState({ hours: 14, minutes: 32, seconds: 45 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: 59, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return { hours: 23, minutes: 59, seconds: 59 };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatNumber = (num: number) => num.toString().padStart(2, '0');

  const whatsappDealUrl = generateSingleProductWhatsAppLink(
    featuredDealProduct,
    1,
    config,
    { notes: 'Claiming the Limited-Time Deal of the Day special price!' }
  );

  return (
    <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 border-y border-blue-900/40 text-white py-8 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
          
          {/* Left: Deal announcement & timer */}
          <div className="space-y-3 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-full text-xs font-semibold">
              <Flame className="w-4 h-4 text-amber-400 fill-amber-400" />
              <span>FLASH TECH SALE · LIMITED ALLOCATION</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Deal of the Day: Save up to {featuredDealProduct.discountPercentage}% Off
            </h2>

            <p className="text-sm text-slate-300 max-w-xl">
              Special promotional price on the {featuredDealProduct.name}. Direct from verified distributor inventory with full {featuredDealProduct.warranty}.
            </p>

            {/* Countdown Display */}
            <div className="flex items-center justify-center lg:justify-start gap-2 pt-1">
              <Clock className="w-4 h-4 text-blue-400" />
              <span className="text-xs text-slate-400 mr-2">Deal expires in:</span>
              <div className="flex items-center gap-1.5 font-mono text-sm font-bold">
                <span className="bg-slate-800/90 border border-slate-700 px-2 py-1 rounded text-white tabular-nums">
                  {formatNumber(timeLeft.hours)}h
                </span>
                <span className="text-slate-500">:</span>
                <span className="bg-slate-800/90 border border-slate-700 px-2 py-1 rounded text-white tabular-nums">
                  {formatNumber(timeLeft.minutes)}m
                </span>
                <span className="text-slate-500">:</span>
                <span className="bg-slate-800/90 border border-slate-700 px-2 py-1 rounded text-amber-400 tabular-nums">
                  {formatNumber(timeLeft.seconds)}s
                </span>
              </div>
            </div>
          </div>

          {/* Right: Featured Product Compact Card */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center gap-5 w-full lg:w-auto shadow-xl">
            <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-xl overflow-hidden bg-slate-950 shrink-0">
              <img
                src={featuredDealProduct.image}
                alt={featuredDealProduct.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              {featuredDealProduct.discountPercentage && (
                <span className="absolute top-1.5 left-1.5 bg-rose-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
                  -{featuredDealProduct.discountPercentage}%
                </span>
              )}
            </div>

            <div className="text-center sm:text-left space-y-2">
              <span className="text-xs text-blue-400 font-semibold tracking-wide">
                {featuredDealProduct.brand} · {featuredDealProduct.categoryLabel}
              </span>
              <h3 className="font-bold text-base text-white line-clamp-1 max-w-xs">
                {featuredDealProduct.name}
              </h3>

              <div className="flex items-baseline justify-center sm:justify-start gap-2">
                <span className="text-xl font-extrabold text-white">
                  {config.currencySymbol}{featuredDealProduct.price.toLocaleString()}
                </span>
                {featuredDealProduct.originalPrice && (
                  <span className="text-sm text-slate-500 line-through">
                    {config.currencySymbol}{featuredDealProduct.originalPrice.toLocaleString()}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2 pt-1">
                <a
                  href={whatsappDealUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors whitespace-nowrap shadow-sm"
                >
                  <MessageCircle className="w-3.5 h-3.5 fill-white/20" />
                  <span>Claim on WhatsApp</span>
                </a>
                <button
                  onClick={() => onOpenProduct(featuredDealProduct)}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg transition-colors whitespace-nowrap"
                >
                  Specs
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
