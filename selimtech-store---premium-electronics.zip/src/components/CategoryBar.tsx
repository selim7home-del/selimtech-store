import React from 'react';
import { 
  Smartphone, 
  Laptop, 
  Monitor, 
  Tv, 
  Headphones, 
  Watch, 
  Zap, 
  Gamepad2, 
  Grid2X2 
} from 'lucide-react';
import { ProductCategory } from '../types/store';
import { CATEGORIES } from '../data/products';

interface CategoryBarProps {
  selectedCategory: ProductCategory;
  onSelectCategory: (category: ProductCategory) => void;
  productCounts: Record<ProductCategory, number>;
}

export const CategoryBar: React.FC<CategoryBarProps> = ({
  selectedCategory,
  onSelectCategory,
  productCounts,
}) => {
  const getCategoryIcon = (id: ProductCategory) => {
    switch (id) {
      case 'smartphones': return <Smartphone className="w-4 h-4" />;
      case 'laptops': return <Laptop className="w-4 h-4" />;
      case 'desktops': return <Monitor className="w-4 h-4" />;
      case 'smart_tvs': return <Tv className="w-4 h-4" />;
      case 'headphones': return <Headphones className="w-4 h-4" />;
      case 'smartwatches': return <Watch className="w-4 h-4" />;
      case 'chargers_accessories': return <Zap className="w-4 h-4" />;
      case 'other_electronics': return <Gamepad2 className="w-4 h-4" />;
      default: return <Grid2X2 className="w-4 h-4" />;
    }
  };

  return (
    <div className="w-full bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-base font-bold text-slate-900 tracking-tight">
            Browse by Department
          </h2>
          <span className="text-xs text-slate-500 font-medium">
            Showing category: <span className="text-blue-600 font-semibold">{CATEGORIES.find(c => c.id === selectedCategory)?.label || 'All'}</span>
          </span>
        </div>

        {/* Scrollable Category Segmented Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none no-scrollbar">
          {CATEGORIES.map((cat) => {
            const count = productCounts[cat.id] ?? 0;
            const isSelected = selectedCategory === cat.id;

            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-sm ring-2 ring-blue-600/30'
                    : 'bg-slate-100 hover:bg-slate-200/80 text-slate-700 hover:text-slate-900 border border-slate-200/60'
                }`}
              >
                <span className={isSelected ? 'text-white' : 'text-slate-500'}>
                  {getCategoryIcon(cat.id)}
                </span>
                <span>{cat.label}</span>
                <span className={`text-[11px] px-1.5 py-0.2 rounded-full ${
                  isSelected ? 'bg-blue-700 text-blue-100' : 'bg-slate-200 text-slate-600'
                }`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
