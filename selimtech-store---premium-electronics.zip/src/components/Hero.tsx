import React from 'react';
import { 
  ArrowRight, 
  MessageCircle, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Zap, 
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { StoreConfig } from '../types/store';
import { HERO_SHOWCASE_IMAGE } from '../data/products';

interface HeroProps {
  config: StoreConfig;
  onExploreCatalog: () => void;
  onViewOffers: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  config,
  onExploreCatalog,
  onViewOffers,
}) => {
  const whatsappUrl = `https://wa.me/${config.whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
    `Hello ${config.storeName}! 👋 I am visiting your store and would like to inquire about your latest electronics and available stock.`
  )}`;

  return (
    <section className="relative bg-slate-950 text-white overflow-hidden">
      {/* Subtle blue ambient radial glow */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Headline and Call-to-Actions */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-950/80 border border-blue-800/40 rounded-full text-blue-300 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>Official 2026 Tech Collection In Stock</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight lg:leading-tight text-balance">
              Next-Generation Electronics Engineered for Excellence
            </h1>

            <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl">
              Discover flagship smartphones, high-performance laptops, 4K Smart TVs, 
              and audiophile sound. Every item is verified authentic with full official warranty 
              and direct one-click WhatsApp ordering.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onExploreCatalog}
                className="px-6 py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm rounded-xl transition-all shadow-lg shadow-blue-600/25 flex items-center gap-2 group whitespace-nowrap"
              >
                <span>Explore Catalog</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm rounded-xl transition-all shadow-lg shadow-emerald-600/20 flex items-center gap-2.5 whitespace-nowrap"
              >
                <MessageCircle className="w-4 h-4 fill-white/20" />
                <span>Order via WhatsApp</span>
              </a>

              <button
                onClick={onViewOffers}
                className="px-5 py-3.5 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 hover:border-slate-700 font-medium text-sm rounded-xl transition-colors whitespace-nowrap"
              >
                View Special Offers
              </button>
            </div>

            {/* Quick Guarantees Checklist */}
            <div className="pt-4 flex flex-wrap gap-y-2 gap-x-6 text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                No middleman markup
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Pay on delivery available
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Fast dispatch in 24 hours
              </span>
            </div>
          </div>

          {/* Right Column: Hero High-Fidelity Asset */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-slate-800 shadow-2xl bg-slate-900 group">
              <img
                src={HERO_SHOWCASE_IMAGE}
                alt="SelimTech Store Premium Electronics Lineup"
                className="w-full aspect-[16/10] sm:aspect-[16/9] lg:aspect-[4/3] object-cover transition-transform duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  // Resilient fallback container if needed
                  const target = e.currentTarget;
                  target.style.display = 'none';
                  const fallback = target.nextElementSibling;
                  if (fallback) fallback.classList.remove('hidden');
                }}
              />
              {/* Fallback container if image blocked */}
              <div className="hidden aspect-[4/3] w-full bg-gradient-to-br from-slate-900 to-blue-950 flex flex-col items-center justify-center p-6 text-center">
                <Zap className="w-12 h-12 text-blue-500 mb-2" />
                <h3 className="font-bold text-lg text-white">SelimTech Flagship Showcase</h3>
                <p className="text-xs text-slate-400 mt-1">Smartphones · Laptops · Audio Gear</p>
              </div>

              {/* Live Availability Badge */}
              <div className="absolute bottom-3 left-3 right-3 bg-slate-950/85 backdrop-blur-md border border-slate-800/80 rounded-xl p-3 flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-400">Featured Flagship</p>
                  <p className="text-sm font-bold text-white">Titanium Pro 5G & M4 Max</p>
                </div>
                <button
                  onClick={onExploreCatalog}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg transition-colors"
                >
                  View Details
                </button>
              </div>
            </div>
          </div>

        </div>

        {/* 4-Item KPI / Trust Bar below Hero */}
        <div className="mt-12 pt-8 border-t border-slate-800/80 grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-white">100% Genuine Tech</h4>
              <p className="text-xs text-slate-400 mt-0.5">Brand new, sealed boxes from authorized sources</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-600/20 text-emerald-400 flex items-center justify-center shrink-0">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-white">Direct WhatsApp Order</h4>
              <p className="text-xs text-slate-400 mt-0.5">Quick confirmation with zero checkout hassle</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-white">Express Delivery</h4>
              <p className="text-xs text-slate-400 mt-0.5">Free delivery for all orders over {config.currencySymbol}{config.freeShippingThreshold.toLocaleString()}</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-purple-600/20 text-purple-400 flex items-center justify-center shrink-0">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-white">Warranty Assured</h4>
              <p className="text-xs text-slate-400 mt-0.5">Up to 2 years full manufacturer warranty support</p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
