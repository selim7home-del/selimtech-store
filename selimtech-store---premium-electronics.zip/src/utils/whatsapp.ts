import { Product, CartItem, StoreConfig } from '../types/store';

export interface OrderCustomerInfo {
  name?: string;
  phone?: string;
  address?: string;
  notes?: string;
}

/**
 * Clean phone number by removing +, spaces, dashes, parentheses
 */
export function sanitizeWhatsAppNumber(phone: string): string {
  return phone.replace(/[^0-9]/g, '');
}

/**
 * Generate a pre-filled WhatsApp link for ordering a single product
 */
export function generateSingleProductWhatsAppLink(
  product: Product,
  quantity: number = 1,
  config: StoreConfig,
  customerInfo?: OrderCustomerInfo
): string {
  const cleanNumber = sanitizeWhatsAppNumber(config.whatsappNumber);
  const total = (product.price * quantity).toFixed(2);
  const currency = config.currencySymbol;

  const lines = [
    `👋 *Hello ${config.storeName}!*`,
    `I would like to place an order for the following item:`,
    ``,
    `📱 *Product:* ${product.name}`,
    `🏷️ *Brand:* ${product.brand}`,
    `📂 *Category:* ${product.categoryLabel}`,
    `💰 *Unit Price:* ${currency}${product.price.toLocaleString()}`,
    `🔢 *Quantity:* ${quantity}`,
    `💵 *Total Amount:* ${currency}${Number(total).toLocaleString()}`,
  ];

  if (product.warranty) {
    lines.push(`🛡️ *Warranty:* ${product.warranty}`);
  }

  if (customerInfo?.name) {
    lines.push(``, `👤 *Customer Name:* ${customerInfo.name}`);
  }
  if (customerInfo?.phone) {
    lines.push(`📞 *Customer Phone:* ${customerInfo.phone}`);
  }
  if (customerInfo?.address) {
    lines.push(`📍 *Delivery Address:* ${customerInfo.address}`);
  }
  if (customerInfo?.notes) {
    lines.push(`📝 *Special Instructions:* ${customerInfo.notes}`);
  }

  lines.push(
    ``,
    `Please confirm product availability, payment options, and delivery timeline. Thank you!`
  );

  const message = lines.join('\n');
  return `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;
}

/**
 * Generate a pre-filled WhatsApp link for checking out the entire cart
 */
export function generateCartWhatsAppLink(
  items: CartItem[],
  config: StoreConfig,
  customerInfo?: OrderCustomerInfo
): string {
  const cleanNumber = sanitizeWhatsAppNumber(config.whatsappNumber);
  const currency = config.currencySymbol;

  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const isFreeShipping = subtotal >= config.freeShippingThreshold;
  const shippingCost = isFreeShipping ? 0 : 500;
  const grandTotal = subtotal + shippingCost;

  const lines = [
    `🛒 *NEW ORDER REQUEST - ${config.storeName}*`,
    `Hello! I would like to order the items listed below:`,
    ``,
    `──────────────`,
    `📋 *ORDER SUMMARY:*`,
    `──────────────`,
  ];

  items.forEach((item, index) => {
    const itemTotal = (item.product.price * item.quantity).toFixed(2);
    lines.push(
      `${index + 1}. *${item.product.name}*`,
      `   • Qty: ${item.quantity} × ${currency}${item.product.price.toLocaleString()}`,
      `   • Subtotal: ${currency}${Number(itemTotal).toLocaleString()}`
    );
  });

  lines.push(
    `──────────────`,
    `💵 *Subtotal:* ${currency}${subtotal.toLocaleString()}`,
    `🚚 *Delivery:* ${isFreeShipping ? 'FREE' : `${currency}${shippingCost}`}`,
    `🌟 *GRAND TOTAL:* ${currency}${grandTotal.toLocaleString()}`,
    `──────────────`
  );

  if (customerInfo?.name) {
    lines.push(`👤 *Name:* ${customerInfo.name}`);
  }
  if (customerInfo?.phone) {
    lines.push(`📞 *Phone:* ${customerInfo.phone}`);
  }
  if (customerInfo?.address) {
    lines.push(`📍 *Delivery Address:* ${customerInfo.address}`);
  }
  if (customerInfo?.notes) {
    lines.push(`📝 *Notes:* ${customerInfo.notes}`);
  }

  lines.push(
    ``,
    `Please confirm the order and send payment/delivery details. Thank you!`
  );

  const message = lines.join('\n');
  return `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;
}

/**
 * General customer support inquiry via WhatsApp
 */
export function generateGeneralInquiryWhatsAppLink(config: StoreConfig, topic: string = 'General Inquiry'): string {
  const cleanNumber = sanitizeWhatsAppNumber(config.whatsappNumber);
  const message = `Hello ${config.storeName}! 👋\nI have a question regarding: *${topic}*.\nCould you please assist me?`;
  return `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;
}
